Como correr os programas:
"python bst.py"
"python avltree.py"
"python linkedlist.py"

Exemplo de correr casos de teste:
"python bst.py < pesquisa264.txt"